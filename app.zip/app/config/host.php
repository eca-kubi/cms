<?php
const URL_ROOT = 'http://sms2.arlgh.com/cms';
const HOST = 'http://sms2.arlgh.com';
?>